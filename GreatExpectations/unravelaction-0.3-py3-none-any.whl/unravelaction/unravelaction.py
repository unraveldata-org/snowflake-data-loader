import copy
import json
import uuid
from ast import literal_eval as make_tuple
from datetime import date, datetime
from typing import Union

import requests
from great_expectations.checkpoint.actions import ValidationAction
from great_expectations.core import ExpectationSuiteValidationResult
from great_expectations.data_context.types.resource_identifiers import (
    ValidationResultIdentifier
)

expectation_hitdoc_mappings_v1 = {
    "expect_column_distinct_values_to_be_in_set": {
        "eventName": "QualityEvent",
        "eventType": "QualityEvent",
        "title": "Expectation Failure {}- expect_column_distinct_values_to_be_in_set",
        "detail": "<ul><li>The range of values in the column is outside the specified range</li></ul>",
        "actions": "<ul><li>A mismatch in the expected values in rows is usually an indicator of outliers. "
                   "Review the relevant code for recent changes</li></ul>"},
    "expect_column_values_to_not_be_null": {
        "eventName": "QualityEvent",
        "eventType": "QualityEvent",
        "title": "Expectation Failure {} - expect_column_values_to_not_be_null",
        "detail": "<ul><li>There are some null values in the column.</li></ul>",
        "actions": "<ul><li>Review relevent code to fix the issue</li></ul>"
    },
    "expect_table_row_count_to_be_between": {
        "eventName": "QualityEvent",
        "eventType": "QualityEvent",
        "title": "Expectation Failure {}- expect_table_row_count_to_be_between",
        "detail": "<ul><li>Table row count is outside the specified range.</li></ul>",
        "actions": "<ul><li>A mismatch in the expected values in tables is usually an indicator of outliers."
                   "Review the relevant code for recent changes</li></ul>"
    }
}

expectation_hitdoc_mappings_v2 = {
    "expect_column_distinct_values_to_be_in_set": {
        "name": "QualityEvent",
        "title": "Expectation Failure {}- expect_column_distinct_values_to_be_in_set",
        "detail": "<ul><li>The range of values in the column is outside the specified range</li></ul>"
    },
    "expect_column_values_to_not_be_null": {
        "name": "QualityEvent",
        "title": "Expectation Failure {} - expect_column_values_to_not_be_null",
        "detail": "<ul><li>There are some null values in the column.</li></ul>"
    },
    "expect_table_row_count_to_be_between": {
        "name": "QualityEvent",
        "title": "Expectation Failure {}- expect_table_row_count_to_be_between",
        "detail": "<ul><li>Table row count is outside the specified range.</li></ul>",
    }
}


class UnravelAction(ValidationAction):
    """
    params:
        msg: expectations template || This is deprecated use expectation_templates instead.
        expectation_templates: expectations template
        clusterUid: clusterUid [default: 'default']
        lr_url: unravel lr endpoint [default: http://localhost:4043]
        lr_version: "v1" for elasticsearch and "v2" for opensearch [default: v1]
        index: es ev index name [default: ev-]
        cert: client certs path [optional],
             usage: a tuple containing certs path ('key.pem', 'cert.pem')
        verify_server: verification of the servers certificate, options: true, false, 'path/to/ca/file' [default: true]
    """

    def __init__(self, data_context, cluster_id='default', msg=None, expectation_templates=None,
                 lr_url="http://localhost:4043", lr_version="v1",
                 index=None, cert=None, verify_server='true') -> None:
        super().__init__(data_context)
        self.lr_version = lr_version
        cert = make_tuple(cert) if cert else None
        if expectation_templates is None:
            if msg is not None:
                expectation_templates = msg
        if verify_server == 'true':
            verify_server = True
        elif verify_server == 'false':
            verify_server = False
        else:
            verify_server = verify_server
        if self.lr_version not in ["v1", "v2"]:
            raise Exception(f"lr version is not valid: {self.lr_version}")
        if self.lr_version == "v2":
            expectation_templates = expectation_templates if expectation_templates else expectation_hitdoc_mappings_v2
            self.strategy = UnravelLRV2(expectation_templates=expectation_templates, cluster_id=cluster_id,
                                        verify_server=verify_server, cert=cert,
                                        index=index, lr_url=lr_url)
        else:
            expectation_templates = expectation_templates if expectation_templates else expectation_hitdoc_mappings_v1
            self.strategy = UnravelLRV1(expectation_templates=expectation_templates, cluster_id=cluster_id,
                                        verify_server=verify_server, cert=cert,
                                        index=index, lr_url=lr_url)

    def _run(self, validation_result_suite: ExpectationSuiteValidationResult, validation_result_suite_identifier: Union[
        ValidationResultIdentifier
    ], data_asset,
             expectation_suite_identifier=None,
             checkpoint_identifier=None, payload=None, ):
        epoch_time = self.get_epoch(validation_result_suite['meta']['validation_time'])
        db = validation_result_suite["meta"]["active_batch_definition"].get("datasource_name", "")
        table = validation_result_suite["meta"]["active_batch_definition"].get("data_asset_name", "")
        schema = validation_result_suite["meta"]["batch_spec"].get("schema_name", "")
        checkpoint_name = validation_result_suite["meta"]["checkpoint_name"]
        expectation_suite_name = validation_result_suite["meta"]["expectation_suite_name"]
        if len(db) > 0 and len(table) > 0:
            if len(schema) > 0:
                entity_id = f"{db}.{schema}.{table}"
            else:
                entity_id = f"{db}.{table}"
        else:
            entity_id = db or table

        utc_event_time = datetime.utcfromtimestamp(int(epoch_time)).strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]
        default_args_details = f'<li>event_time : {utc_event_time} UTC</li>' \
                               f'<li>checkpoint_name : {checkpoint_name}</li>' \
                               f'<li>expectation_suite_name : {expectation_suite_name}</li>'

        exceptions = self.strategy.generate_exception_json(validation_result_suite=validation_result_suite,
                                                           entity_id=entity_id, epoch_time=epoch_time,
                                                           default_args_details=default_args_details)
        self.strategy.send_to_lr(exceptions)

    @staticmethod
    def get_epoch(event_time):
        event_time_format = '%Y%m%dT%H%M%S.%fZ'
        epoch = datetime(1970, 1, 1)
        return int((datetime.strptime(event_time, event_time_format) - epoch).total_seconds())


class UnravelLRV1:
    """
    This class is for supporting unravel_version < 4.8
    """

    def __init__(self, expectation_templates, cluster_id, index, lr_url, verify_server, cert):
        self.expectation_templates = expectation_templates
        self.cluster_id = cluster_id
        self.index = index if index else 'ev-'
        self.lr_url = lr_url
        self.verify_server = verify_server
        self.cert = cert
        if self.lr_url.split(':')[0] != 'https' and self.lr_url.split(':')[0] != 'http':
            raise Exception(f"lr url protocol is not valid: {self.lr_url}")

    def generate_exception_json(self, validation_result_suite, entity_id, epoch_time,
                                default_args_details) -> list:
        expectations = []
        if not validation_result_suite["success"]:
            for result in validation_result_suite["results"]:
                if not result["success"]:
                    exception_raised = result["exception_info"]["raised_exception"]

                    # checking exceptions
                    if exception_raised:
                        print(result["exception_info"]["exception_traceback"])
                        print(result["exception_info"]["exception_message"])
                        continue

                    expectation_config = result.expectation_config
                    exception_json = copy.deepcopy(self.expectation_templates.get(expectation_config.expectation_type))

                    if exception_json is None:
                        exception_json = {
                            "eventName": "QualityEvent",
                            "eventType": "QualityEvent",
                            "title": f"Expectation Failure on {entity_id} -" + expectation_config.expectation_type,
                            "detail": f"expectation: {expectation_config.expectation_type}",
                            "actions": "<ul><li>Review relevant code to fix the issue</li></ul>"
                        }
                    elif entity_id:
                        exception_json['title'] = exception_json['title'].format(f"on {entity_id}")

                    exception_json['eventTime'] = epoch_time
                    exception_json['entityId'] = entity_id.lower()
                    exception_json['clusterUid'] = self.cluster_id
                    exception_json['eventName'] += '-Failure'

                    args_details = default_args_details

                    for key, value in result['expectation_config']['kwargs'].items():
                        if key != 'batch_id':
                            args_details += f"<li>{key} : {value}</li>"

                    if args_details:
                        exception_json['detail'] += f"<ul>{args_details}</ul>"
                    expectations.append(exception_json)
        else:
            exception_json = {
                "eventName": "QualityEvent-Success",
                "eventType": "QualityEvent",
                "title": f"Expectation suite Passed on {entity_id}",
                "detail": "",
                "actions": "<ul><li>No action required</li></ul>",
                'eventTime': epoch_time,
                'entityId': entity_id.lower(),
                'clusterUid': self.cluster_id
            }
            expectations.append(exception_json)
        return expectations

    @staticmethod
    def index_for_timestamp(prefix):
        ts = date.today()
        year = ts.strftime("%Y")
        month = ts.strftime("%m")
        day = ts.strftime("%d")
        d = datetime(int(year), int(month), int(day)).toordinal()
        sunday = str(datetime.fromordinal(d - (d % 7)))[8:10]
        saturday = str(datetime.fromordinal(d - (d % 7) + 6))[8:10]
        return prefix + year + month + sunday + "_" + saturday

    def send_to_lr(self, expectations):
        for exception_json in expectations:
            hitdoc_id = datetime.now().strftime('%Y%m%d%H%M%S%f')
            index = self.index_for_timestamp(self.index)
            exception_json = json.dumps(exception_json)
            body = f'{index} event {hitdoc_id} {hitdoc_id} {exception_json}'
            headers = {'Content-Type': 'application/json'}
            try:
                r = requests.put(url=f'{self.lr_url}/logs/hl/hl/{hitdoc_id}/_bulkr', data=body, headers=headers,
                                 verify=self.verify_server,
                                 cert=self.cert)
                if r.status_code // 100 != 2:
                    print(f'LR request failed: status={r.status_code} body={body} resp={r.text} \n')
            except Exception as err:
                print(f'LR request failed: body={body} error={err}')


class UnravelLRV2(UnravelLRV1):
    """
    This class is for supporting unravel_version >= 4.8
    """

    def __init__(self, expectation_templates, cluster_id, index, lr_url, verify_server, cert):
        index = index if index else "events_ge_t1-"
        super().__init__(expectation_templates, cluster_id, index, lr_url, verify_server, cert)

    def generate_exception_json(self, validation_result_suite, entity_id, epoch_time,
                                default_args_details) -> list:
        expectations = []
        if not validation_result_suite["success"]:
            for result in validation_result_suite["results"]:
                if not result["success"]:
                    exception_raised = result["exception_info"]["raised_exception"]

                    # checking exceptions
                    if exception_raised:
                        print(result["exception_info"]["exception_traceback"])
                        print(result["exception_info"]["exception_message"])
                        continue

                    expectation_config = result.expectation_config
                    exception_json = copy.deepcopy(self.expectation_templates.get(expectation_config.expectation_type))
                    entity = {}
                    if exception_json is None:
                        exception_json = {
                            "name": "QualityEvent",
                            "title": f"Expectation Failure on {entity_id} -" + expectation_config.expectation_type,
                            "detail": f"expectation: {expectation_config.expectation_type}"
                        }
                    elif entity_id:
                        exception_json['title'] = exception_json['title'].format(f"on {entity_id}")

                    entity['uid'] = entity_id
                    entity['type'] = "T"
                    entity['group'] = "D"

                    exception_json['start_time'] = datetime.fromtimestamp(epoch_time).strftime("%Y-%m-%dT%H:%M:%S.%fZ")
                    exception_json['created'] = datetime.fromtimestamp(epoch_time).strftime("%Y-%m-%dT%H:%M:%S.%fZ")
                    exception_json['category'] = "A"
                    exception_json['reason'] = exception_json['title']
                    exception_json['id'] = "ge" + str(epoch_time) + "_" + str(uuid.uuid4())
                    exception_json['name'] += '-Failure'
                    exception_json['provider'] = "great_expectations"
                    exception_json['severity'] = 5
                    exception_json["entity"] = entity
                    args_details = default_args_details

                    for key, value in result['expectation_config']['kwargs'].items():
                        if key != 'batch_id':
                            args_details += f"<li>{key} : {value}</li>"

                    if args_details:
                        exception_json['detail'] += f"<ul>{args_details}</ul>"
                    expectations.append(exception_json)
        else:
            entity = {'uid': entity_id, 'type': "T", 'group': "D"}
            exception_json = {
                "start_time": datetime.fromtimestamp(epoch_time).strftime("%Y-%m-%dT%H:%M:%S.%fZ"),
                "created": datetime.fromtimestamp(epoch_time).strftime("%Y-%m-%dT%H:%M:%S.%fZ"),
                "category": "L",
                "reason": f"Expectation suite Passed on {entity_id}",
                "id": "ge" + str(epoch_time) + "_" + str(uuid.uuid4()),
                "name": "QualityEvent-Success",
                "title": f"Expectation suite Passed on {entity_id}",
                "detail": "",
                "provider": "great_expectations",
                "severity": 10,
                "entity": entity
            }
            expectations.append(exception_json)
        return expectations

    def send_to_lr(self, expectations):
        for exception_json in expectations:
            hitdoc_id = exception_json["id"]
            index = self.index_for_timestamp(self.index)
            body = [{
                "docId": hitdoc_id,
                "document": exception_json,
                "documentType": "com.fasterxml.jackson.databind.node.ObjectNode",
                "index": index,
                "opType": "index"
            }]
            body = json.dumps(body)
            headers = {'Content-Type': 'application/json'}
            try:
                r = requests.put(url=f'{self.lr_url}/logs/hl/hl/{hitdoc_id}/_bulkr', data=body, headers=headers,
                                 verify=self.verify_server,
                                 cert=self.cert)
                if r.status_code // 100 != 2:
                    print(f'LR request failed: status={r.status_code} body={body} resp={r.text} \n')
            except Exception as err:
                print(f'LR request failed: body={body} error={err}')
